const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const WebSocket = require('ws');

const app = express();
const server = http.createServer(app);
const io = socketIo(server);

// WebSocket Server for ESP32
const wss = new WebSocket.Server({ server, path: '/ws' });

// Store ESP32 connection
let esp32Socket = null;

// Serve static files
app.use(express.static('public'));

// Handle client connections
io.on('connection', (socket) => {
  console.log('Client connected:', socket.id);

  // Send current ESP32 status
  socket.emit('esp32-status', esp32Socket ? 'connected' : 'disconnected');

  // Receive command from client
  socket.on('command', (data) => {
    console.log('Received command from client:', data);
    if (esp32Socket && esp32Socket.readyState === WebSocket.OPEN) {
      esp32Socket.send(JSON.stringify(data));
      console.log('Sent command to ESP32:', data);
    } else {
      console.log('ESP32 not connected');
    }
  });

  socket.on('disconnect', () => {
    console.log('Client disconnected:', socket.id);
  });
});

// Handle ESP32 connections
wss.on('connection', (ws) => {
  console.log('ESP32 connected');
  esp32Socket = ws;

  // Notify clients that ESP32 is connected
  io.emit('esp32-status', 'connected');

  ws.on('message', (message) => {
    console.log('Message from ESP32:', message);
    // Optionally send messages to clients
  });

  ws.on('close', () => {
    console.log('ESP32 disconnected');
    esp32Socket = null;
    io.emit('esp32-status', 'disconnected');
  });
});

// Start server
const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
