const socket = io();

// Status display
const statusIndicator = document.getElementById('status');

// Control buttons
const forwardBtn = document.getElementById('forward');
const backwardBtn = document.getElementById('backward');
const leftBtn = document.getElementById('left');
const rightBtn = document.getElementById('right');

// Gear buttons
const gearButtons = document.querySelectorAll('.gear');

// Current gear level
let currentGear = 0; // Default to Neutral

// Update status function
function updateStatus(status) {
  if (status === 'connected') {
    statusIndicator.textContent = 'Robot connected';
    statusIndicator.style.color = 'green';
  } else {
    statusIndicator.textContent = 'Robot not connected';
    statusIndicator.style.color = 'red';
  }
}

// Receive status from server
socket.on('esp32-status', (status) => {
  updateStatus(status);
});

// Function to send command with current gear
function sendCommand(command) {
  // If gear is Neutral (0), stop the robot
  if (currentGear === 0) {
    socket.emit('command', { command: 'stop', gear: currentGear });
  } else {
    socket.emit('command', { command: command, gear: currentGear });
  }
}

// Press-and-hold event listeners
function addPressAndHold(button, command) {
  let isPressed = false;

  function startCommand() {
    if (currentGear !== 0) {
      sendCommand(command);
      button.classList.add('active'); // Add active class
    }
  }

  function stopCommand() {
    sendCommand('stop');
    button.classList.remove('active'); // Remove active class
  }

  button.addEventListener('mousedown', () => {
    isPressed = true;
    startCommand();
  });
  button.addEventListener('mouseup', () => {
    isPressed = false;
    stopCommand();
  });
  button.addEventListener('mouseleave', () => {
    if (isPressed) {
      isPressed = false;
      stopCommand();
    }
  });
  button.addEventListener('touchstart', (e) => {
    e.preventDefault();
    isPressed = true;
    startCommand();
  });
  button.addEventListener('touchend', () => {
    isPressed = false;
    stopCommand();
  });
}

addPressAndHold(forwardBtn, 'forward');
addPressAndHold(backwardBtn, 'backward');
addPressAndHold(leftBtn, 'left');
addPressAndHold(rightBtn, 'right');

// Keyboard controls
document.addEventListener('keydown', (e) => {
  if (e.repeat) return; // Ignore if key is held down
  switch (e.key.toLowerCase()) {
    case 'w':
      if (currentGear !== 0) {
        sendCommand('forward');
        forwardBtn.classList.add('active'); // Add active class
      }
      break;
    case 's':
      if (currentGear !== 0) {
        sendCommand('backward');
        backwardBtn.classList.add('active'); // Add active class
      }
      break;
    case 'a':
      if (currentGear !== 0) {
        sendCommand('left');
        leftBtn.classList.add('active'); // Add active class
      }
      break;
    case 'd':
      if (currentGear !== 0) {
        sendCommand('right');
        rightBtn.classList.add('active'); // Add active class
      }
      break;
  }
});

document.addEventListener('keyup', (e) => {
  switch (e.key.toLowerCase()) {
    case 'w':
      sendCommand('stop');
      forwardBtn.classList.remove('active'); // Remove active class
      break;
    case 's':
      sendCommand('stop');
      backwardBtn.classList.remove('active'); // Remove active class
      break;
    case 'a':
      sendCommand('stop');
      leftBtn.classList.remove('active'); // Remove active class
      break;
    case 'd':
      sendCommand('stop');
      rightBtn.classList.remove('active'); // Remove active class
      break;
  }
});

// Gear selection
gearButtons.forEach((button) => {
  button.addEventListener('click', () => {
    currentGear = parseInt(button.getAttribute('data-gear'));
    // Update button styles to reflect current gear
    gearButtons.forEach((btn) => {
      btn.classList.remove('active');
    });
    button.classList.add('active');
  });
});

// Set default gear to Neutral
document.querySelector('.gear[data-gear="0"]').classList.add('active');
